# MetricsWeighted 0.2.0

* Improvement of documentation and examples. 

* Better handling of Tweedie special cases.

* More strict error handling.

* Added median absolute error (and weighted_median, weighted_quantile)

