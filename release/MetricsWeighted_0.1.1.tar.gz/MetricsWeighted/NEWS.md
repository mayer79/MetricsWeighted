# MetricsWeighted 0.1.1

* Improvement of documentation and examples. Better handling of Tweedie special cases.

