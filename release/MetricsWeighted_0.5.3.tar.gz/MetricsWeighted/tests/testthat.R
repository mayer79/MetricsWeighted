library(testthat)
library(MetricsWeighted)

test_check("MetricsWeighted")
