# MetricsWeighted

This R package provides weighted versions of several metrics used in machine learning.